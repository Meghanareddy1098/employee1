package com.servlet;

public class printWrite {

	public void print(String string) {
		// TODO Auto-generated method stub
		
	}

}
